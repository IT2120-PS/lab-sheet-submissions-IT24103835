setwd("C:\\Users\\User\\OneDrive\\Desktop\\PSLab08")

# Load the dataset
data<-read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)

# Extract the weight column
weights <- data$Weight

# Population statistics
pop_mean<-mean(weights)
pop_sd<-sd(weights)

samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(weights, 6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}

colnames(samples)=n
s.means<-apply(samples,2,mean)
s.sds<-apply(samples,2,sd)

samplemean<-mean(s.means)
samplesds<-var(s.means)

pop_mean
samplemean

pop_sd
samplesds
