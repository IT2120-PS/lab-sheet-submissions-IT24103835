setwd("C:\\Users\\IT24103835\\Desktop\\lab4")
data<-read.table("DATA 4.txt",header=TRUE,sep = " ")
fix(data)
attach(data)

boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline = TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline = TRUE,outpch=8,horizontal=TRUE)

branch_data<-read.table("Exercise.txt",header=TRUE,sep = " ")
str(branch_data)
fix(branch_data)
attach(branch_data)
boxplot(X1,main="Box plot for Sales",outline=TRUE,outpch=8,vertical=TRUE)
summary(X1)
summary(X2)
summary(X3)
IQR(X1)
IQR(X2)
IQR(X3)

get.mode<-function(y){
  count<-table(X3)
  names(counts[counts == max(counts)])
}
get.mode(X3)
table(X3)

get.outlier