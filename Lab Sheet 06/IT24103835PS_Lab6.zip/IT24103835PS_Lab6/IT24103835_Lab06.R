setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24103835PS_Lab6")

##Question 01
#Part 1
#Binomial Distribution
#Here,random variable x has binomial distribution with n = 50 and p = 0.85

#Part 2
#x>47
#1-x<47
P1 <- 1 - pbinom(47,50,0.85,lower.tail = TRUE)
P1

##Question 02
#Part 1
#Number Of customer calls received in a call center per hour

#Part 2
#Poisson distribution
#Here,random variable x has poisson distribution with λ = 12

#part 3
P2 <- dpois(15,5)
P2
